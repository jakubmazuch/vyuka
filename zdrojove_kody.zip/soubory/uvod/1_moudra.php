<DIV>
  <p style="text-align: center"><b>
  <script>
	nahodnytext = new Array(
	  "Nejlepší nápady jsou ty nápady, které vznikají spontánně a individuálně, zhruba 2-6 sekund před jejich uskutečněním. Jejich důsledky jsou tomu však přímo úměrné..." , 
	  "Lepší je si to po**at podle svýho, než podle toho, co ti radej' ti druzí! - Lubomír Lipský (film 2Bobule)" , 
	  "Životní moudrostí je, když se v každém období života dopouštíme jen takových omylů, které jsou v souladu s věkem. — Pablo Picasso" , 
	  "Quidquid discis, tibi discis. (Čemukoli se učíš, učíš se pro sebe.)" ,
	  "Mluviti stříbro, mlčeti zlato." ,
	  "Svoboda a odpovědost jsou dvě strany téže mince - Václav Havel" , 
	  "Nesuď knihu, podle obalu." , 
	  "Carpe diem! (Užívej dne!) - Horatius" , 
	  "Ubi sementem feceris, ita mettes. (Jak zaseješ, tak sklidíš.)" ,
	  "Když nevíš, improvizuj!" ,
	  "Kdo seje vítr, sklízí bouři." ,
	  "Když se objeví Slunce, zmizí hvězdy." ,
	  "Sekerou okno neumyješ." ,
	  "Není tak špatné knihy, aby alespoň v něčem nebyla prospěšná." ,
	  "Non est ad astra mollis e terris via. (Není lehká cesta ze země na měsíc.)" ,
	  "Dokud dýchám, žiju, a dokud žiju, budu bojovat, abych mohl dýchat..." ,
	  "Má-li problém řešení, nemá smysl dělat si starosti. Když řešení nemá, starosti nepomohou. - Dalajláma" ,
	  "Člověk prostě není Bůh a hra na něj se mu krutě mstí. - Václav Havel" ,
	  "Největší chyba, kterou v životě můžete udělat, je mít pořád strach, že nějakou uděláte. - Elbert Hubbard" ,
	  "In necessariis unitas, in dubiis libertas, in omnibus caritas. (V nutném jednota, v nerozhodnutém svoboda, ve všem láska)- sv. Augustus" ,
	  "Co tě nezabije, to tě posílí - Nietzsche" ,
	  "Co nechceš, aby jiní činili tobě, nečiň ty jim!" ,
	  "Není důležité si věci pamatovat, ale vědět, kde je naleznu!" ,
	  "Život je skvělý, jen ho musíš pochopit." ,
	  "Bůh stvořil člověka, ale nedal si to patentovat, a tak to teď po něm může dělat kdejakej blbec. - Jan Werich" ,
	  "Jen dvě věci jsou nekonečné: vesmír a lidská hloupost. A já si nejsem jistý, která tu byla dřív – A. Einstein" ,
	  "Prvním stupněm debility je pocit geniality" , 
	  "Po bouři vždy vyjde slunce."
	);index = Math.floor(Math.random()*nahodnytext.length);
	document.write(nahodnytext[index]);
  </script></b></p>
</DIV>