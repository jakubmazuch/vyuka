<?php

require "pripojeni.php";
$vysledek = mysqli_query($spojeni,  
	"SELECT *, 
	date_format (datum, '%e. %c. %Y, %H:%i:%s') AS datum_cs 
	FROM `novinky`
	ORDER BY `datum` DESC");
/* Konec přímé práce s databází. */

if ($vysledek->num_rows > 0) {		
while ($zaznam = mysqli_fetch_array($vysledek) ): 

echo "<div class='ramecek_uvod'>";
echo "<h2>";
echo $zaznam["nadpis"];
echo "</h2>";
echo "<p>";
echo $zaznam["text"];
echo "</p>";
echo "<div class='podpisovka'>";
echo $zaznam["autor"];
echo " (";
echo $zaznam["datum_cs"];
echo ")</div>";
echo "</div><br>";

endwhile;
}
	else {
		echo "<i>(žádné novinky k zobrazení)</i>";
	}
?>