<?php
function velikost($soubor) {
  $size = @filesize("./".$soubor);
  if($size < 1024) {$size = ($size); $k = " B";}
  if($size >= 1024) {$size = ($size / 1024); $k = " kB";}
  if($size >= 1024) {$size = ($size / 1024); $k = " MB";}
  return round($size, 1).$k; /* 1 = zaokrouhlování na jedno desetinné místo */
}
?>