﻿<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-92617882-1', 'auto');
  ga('send', 'pageview');

</script>
<?php
require "pripojeni.php";
$id = $_GET["s"];
$zadna_data = "<i>Žádná data k dispozici.</i>";


function velikost($soubor) {
  $size = @filesize("./".$soubor);
  if($size < 1024) {$size = ($size); $k = " B";}
  if($size >= 1024) {$size = ($size / 1024); $k = " kB";}
  if($size >= 1024) {$size = ($size / 1024); $k = " MB";}
  return round($size, 1).$k; /* 1 = zaokrouhlování na jedno desetinné místo */
}


$vysledek1 = mysqli_query($spojeni,  
"SELECT * FROM `hodiny` WHERE id = '$id' AND visible = '1'");

if ($vysledek1->num_rows > 0) {	
	while ($zaznam = mysqli_fetch_array($vysledek1) ): 

	$predmet = $zaznam["predmet"];
	$skola = $zaznam["skola"];
	$cas = $zaznam["cas"];
	$sekce = $zaznam["oddeleni"];
	$nazev_robot = $zaznam["nazev_robot"];

	endwhile;
	
	$nadpis = "$predmet- <br>$skola<br>$cas";
	echo "<h1>$nadpis</h1>";
	echo "
	<style>
	  img {cursor: pointer; cursor: hand; text-decoration: underline}
		.skryvany {display: none}
	  tbody:hover {background-color: #f5f5f5; }  
		.a:link {color: red;}
		.a:visited {color: green;}
		.a:hover {color: hotpink;}
		.a:active {color: blue;}
	</style>
	";
	
	echo "
	 <p><i>Naposledy aktualizováno: " ;
	echo (strftime("%d.%m.%Y %H:%M:%S", getlastmod()));
	echo " </i></p> "; 

	//TEXT Nulový znak, pozor!
	if (!strpos($sekce,"xt") === false) {
	echo "text";
	
	}
	// VÝUKOVÉ MATERIÁLY
	if (!strpos($sekce,"soubory") === false) {

	
		echo "<h2>Výukové materiály:</h2>";
		$vysledek = mysqli_query($spojeni,  
		"SELECT * FROM `soubory` WHERE hodina = '$nazev_robot' ORDER BY `datum` DESC");
		if ($vysledek->num_rows > 0) {	
			echo "<div style='padding-left:20px;'>";
			echo "<table frame='hsides' rules='groups'>";

			while ($zaznam = mysqli_fetch_array($vysledek) ): 
			
			//Typ
			$typ = strtolower(substr($zaznam["soubor"],strrpos($zaznam["soubor"],'.') + 1));
			
			//Velikost
			$soubor = $zaznam["soubor"];
			$cesta = "/soubory/soubory/$soubor";
			$velikost = velikost($cesta);

			echo "<tbody>";
			echo "<tr><td width='420px'>";
			echo "<img src='/obrazky/ikony/"; /*obrázek souboru*/
			echo $typ;
			echo ".png' /> ";
			echo $zaznam["nazev_lekce"];
			echo "</td>";
			echo "<td rowspan='2'>";
			echo "<a href='/soubory/soubory/";
			echo $zaznam["soubor"];
			echo "' target='_blank'>";
			require "script.php";
			echo "</a><td></tr>";
			echo "<tr><td align='LEFT'><i style='Font-size:small; color:grey; '>";
			echo "soubor ";
			echo strtoupper($typ);
			echo "  (" . $velikost . ")";
			echo "</td></tr>";
			echo "</tbody>";

			endwhile;
			echo "</table>";
			echo "</div>";
		}
		else {
			echo $zadna_data;;
		}
	}
	//ODKAZY	
	if (!strpos($sekce,"kazy") === false) {
	echo "<h2>Odkazy:</h2>";
	
	$vysledek2 = mysqli_query($spojeni,  
	"SELECT * FROM `odkazy` WHERE skola = '$nazev_robot'");
	if ($vysledek2->num_rows > 0) {	
		echo "<ul>";
		while ($zaznam1 = mysqli_fetch_array($vysledek2) ): 
			echo "<li>";
			echo "<a href='";
			echo $zaznam1["url"];
			echo "' target='_blank'>";
			echo $zaznam1["popisek"];
			echo "</a>";
			echo "</li>";
		endwhile;
		echo "</ul>";
	}
	else {
		echo $zadna_data;
	}
	}
	if (!strpos($sekce,"otogalerie") === false) {
	echo "<h2>Fotogalerie:</h2>";
		echo $zadna_data;
	}
	if (!strpos($sekce,"ideogalerie") === false) {
	echo "<h2>Videogalerie:</h2>";
	
	$vysledek3 = mysqli_query($spojeni,  
	"SELECT * FROM `videa` WHERE skola = '$nazev_robot'");
	if ($vysledek3->num_rows > 0) {
		
		while ($zaznam3 = mysqli_fetch_array($vysledek3) ): 
			echo "<iframe width='";
			echo $zaznam3["sirka"];
			echo "' height='";
			echo $zaznam3["vyska"];
			echo "' src='https://www.youtube.com/embed/";
			echo $zaznam3["id_videa"];
			echo "' frameborder='1' allowfullscreen></iframe>";
		endwhile;
	}
	else {
		echo $zadna_data;
	
	}
}}
	else {
		echo "<i>Hodina není k dispozici!</i>";
	}		
?>
