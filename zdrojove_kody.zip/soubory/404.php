<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-92617882-1', 'auto');
  ga('send', 'pageview');

</script>
<?php
function velikost($soubor) {
  $size = @filesize("./".$soubor);
  if($size < 1024) {$size = ($size); $k = " B";}
  if($size >= 1024) {$size = ($size / 1024); $k = " kB";}
  if($size >= 1024) {$size = ($size / 1024); $k = " MB";}
  return round($size, 1).$k; /* 1 = zaokrouhlování na jedno desetinné místo */
}
$nadpis = "Chyba 404 - stránka nenalezena";
require "hlavicka1.php";
echo "
<p>Moc se Vám omlouvám za vzniklé potíže. Pravděpodobně se mi tu něco nepovedlo..., nebo jste zadali špatnou adresu. Budu rád, když mě o chybě <a href='kontakt.php'>informujete</a>.</p>
<p><i><a href='index.php'>&rsaquo;&rsaquo;&rsaquo;Domovská stránka</a></i></p> ";
 
require "paticka1.php";	 ?>
