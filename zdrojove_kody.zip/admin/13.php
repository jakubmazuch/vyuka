<?php

$nadpis = "Vložení fotografií do galerie";
echo "<h1>$nadpis</h1>";

//ošetření nedefinovaného fileName
$fileName = isset($_GET["fileName"]) ? $_GET["fileName"] : "";
$vyber_galerie = isset($_POST['vyber_galerie']) ? $_POST['vyber_galerie'] : ""; 

echo $vyber_galerie;
 
// konfigurace
$uploadDir = '../fotogalerie'; // adresar, kam se maji nahrat obrazky (bez lomitka na konci)
$allowedExt = array('jpg', 'jpeg', 'png', 'gif', 'bmp', 'tiff',); // pole s povolenymi priponami
 
// zpracovani uploadu
if(isset($_FILES['obrazky']) && is_array($_FILES['obrazky']['name'])) {
 
    $counter = 0;
    $allowedExt = array_flip($allowedExt);
    foreach($_FILES['obrazky']['name'] as $klic => $nazev) {
 
        $fileName = basename($nazev);
        $tmpName = $_FILES['obrazky']['tmp_name'][$klic];
 
        // kontrola souboru
        if(
            !is_uploaded_file($tmpName)
            || !isset($allowedExt[strtolower(pathinfo($fileName, PATHINFO_EXTENSION))])
        ) {
            // neplatny soubor nebo pripona
            continue;
        }
 
        // presun souboru
		$path = "$uploadDir\\$vyber_galerie\\$fileName";
		$vyber_galerie = isset($_POST['vyber_galerie']) ? $_POST['vyber_galerie'] : ""; 
        if(move_uploaded_file($tmpName, $path )) {
            ++$counter;
        }
 
    }
 
    echo "<p>Bylo nahráno {$counter} z ".sizeof($_FILES['obrazky']['name'])." souborů do $path .</p>";
 
};

 
echo "
<h2>a) Upload souborů:</h2>
<form method='post' enctype='multipart/form-data'>
	<input type='file' name='obrazky[]' multiple='multiple' />
	<select name='vyber_galerie'>";
		foreach (glob("../fotogalerie/*", GLOB_NOSORT) as $filename) {
			$filename_simple = basename($filename);
			echo "<option value='$filename_simple'>$filename_simple<option>";
		}
		echo "			
		</select>
    <input type='submit' value='Nahrát' />
</form>";

	?>