<?php
$nadpis = "Vložení videa";
require "pripojeni.php";
echo "<h1>$nadpis</h1>";

//Fomulář pro přidání videa
echo " <form action='index.php?s=pridej_video' method='post'>";
echo "<table>
		<tr><td>Popisek adresy:</td><td><input type='text' name='popisek'/></td><td>pozn. zatím bez užitku</td></tr>
		<tr><td>ID videa:</td><td><input type='text' name='id_videa' value=''/></td><td>(příklad: 5ESHJKat6ds)</td></tr>
		<tr><td>Velikost videa:</td><td><select name='velikost'>
						<option value='male'>Malé (280 × 157,5 px)</option>
						<option value='velke'>Velké (560 × 315 px)</option>
					</select></td></tr>";
			$vysledek1 = mysqli_query($spojeni,  
			"SELECT * FROM `hodiny` WHERE `visible`");
			/* Konec přímé práce s databází. */

			echo "<tr><td>Hodina:</td><td><select name='hodina'>";

			while ($zaznam = mysqli_fetch_array($vysledek1) ): 

			echo "<option value='";
			echo $zaznam["nazev_robot"];
			echo "'>";
			echo $zaznam["nazev_zkr"];
			echo "</option>";

			endwhile;
			echo "</select></td></tr>
		<tr><td><input type='submit' value='Odeslat' /></td></tr>";
echo "</table>";
echo "</form>";

?>