<?php
$nadpis = "Správce odkazů";
require "pripojeni.php";
echo "<h1>$nadpis</h1>";

//ošetření nedefinovaných proměnných
$vysledek2 = isset($_GET["vysledek2"]) ? $_GET["vysledek2"] : "";
$id_2 = isset($_GET["id_2"]) ? $_GET["id_2"] : "";
$nazev_lekce = isset($_GET["nazev_lekce"]) ? $_GET["nazev_lekce"] : "";
$souborx = isset($_GET["souborx"]) ? $_GET["souborx"] : "";

//text
echo "Pro odstranění řádku je nutno kliknou dvakrát na odkaz 'Odstranit'";

//Úprava řádku
if (!isset($_GET['akce'])){$_GET['akce']='';}
if ($_GET['akce'] == "uprav")
{
	$id = $_GET['id'];
$vysledek2 = mysqli_query($spojeni, 
"SELECT * FROM `odkazy` WHERE id=$id");
}
if ($vysledek2->num_rows > 0) {	
	

	while ($zaznam2 = mysqli_fetch_array($vysledek2) ): 
	$id_upr = $zaznam2["id"];
	$popisek_upr = $zaznam2["popisek"];
	$skola_upr = $zaznam2["skola"];
	$url_upr = $zaznam2["url"];
	endwhile;
	
	//formulář pro úpravu záznamu
	echo "<table border='1' style='table-layout: fixed; border-collapse: collapse;'>";
	echo "<tr>
			<td><b>id:</b></td>
			<td><b>popisek:</b></td>
			<td><b>url:</b></td>
			<td><b>skola:</b></td>
			<td><b></b></td>
		</tr>";
	
	echo "<form action='index.php?s=uprava_odkazu' method='post'>";
	echo "<tr>";
	
	echo "<td>";
	echo "<input type='text' value='$id_upr' name='id_upr' size='1' readonly/>";
	echo "</td>";

	echo "<td>";
	echo "<input type='text' value='$popisek_upr' name='popisek_upr' size='7'/>";
	echo "</td>";

	echo "<td>";
	echo "<input type='text' value='$url_upr' name='url_upr' size='12'/>";
	echo "</td><br/><br/>";
	
	echo "<td>";
	$vysledek1 = mysqli_query($spojeni,  
			"SELECT * FROM `hodiny` WHERE `visible`");
			/* Konec přímé práce s databází. */

			echo "<select name='skola_upr'>";

			while ($zaznam = mysqli_fetch_array($vysledek1) ): 

			echo "<option value='";
			echo $zaznam["nazev_robot"];
			echo "' selected='";
			$nazev_zkr1 = $zaznam["nazev_zkr"];
			if ($nazev_zkr1 = $skola_upr) {
				echo "selected";
			}
			else {
				echo "";
			}
			echo "'>";
			echo $zaznam["nazev_zkr"];
			echo "</option>";

			endwhile;
			echo "</select>";
	ECHO "</td>";
	

	echo "<td>";
	echo "<input type='submit' value='Odeslat' />";
	echo "</td>";

	echo "</tr>";
	echo "</form>";
	echo "</table><br/><br/><br/>";
}
else {
	echo "";
}

//Výpis celé tabulky, řadit od nejmladšího dle datumu
$vysledek = mysqli_query($spojeni,  
"SELECT * FROM `odkazy` ORDER BY `id`");


//Odstranění řádku
if (!isset($_GET['akce'])){$_GET['akce']='';}
if ($_GET['akce'] == "odstran")
{
	$id = $_GET['id'];
$vysledek1 = mysqli_query($spojeni, 
"DELETE FROM `odkazy` WHERE id=$id");
}


/* Konec přímé práce s databází. */
echo "<table border='1' style='table-layout: fixed; border-collapse: collapse;'>";
echo "<tr>
	<td><b>id:</b></td>
	<td><b>popisek:</b></td>
	<td><b>url:</b></td>
	<td><b>skola:</b></td>
	<td><b>X</b></td>
</tr>";

while ($zaznam = mysqli_fetch_array($vysledek) ): 

echo "<tr>";

echo "<td>";
echo $zaznam["id"];
echo "</td>";

echo "<td>";
echo $zaznam["popisek"];
echo "</td>";

echo "<td>";
echo $zaznam["url"];
echo "</td>";

echo "<td>";
echo $zaznam["skola"];
echo "</td>";

echo "<td>";
echo "<a href=";
echo "?s=8&akce=odstran&id=";
echo $zaznam['id'];
echo ">";
echo "odstranit</a>";
echo "<br>";
echo "<a href=";
echo "?s=8&akce=uprav&id=";
echo $zaznam['id'];
echo ">";
echo "upravit</a>";
echo "</td>";

echo "</tr>";
endwhile;

echo "</table>";

// odkaz zpět
echo "<a href='";
echo "index.php?s=8.php";
echo "'>Z P Ě T</a>";
?>