<?php
$nadpis = "Přidej hodinu";
require "pripojeni.php";
echo "<h1>$nadpis</h1>";

$popisek = isset($_POST['popisek']) ? $_POST['popisek'] : "";
$id_videa = isset($_POST['id_videa']) ? $_POST['id_videa'] : "";
$velikost = isset($_POST['velikost']) ? $_POST['velikost'] : "";
$hodina = isset($_POST['hodina']) ? $_POST['hodina'] : "";

if ($velikost === "male") {
	$sirka_ramu = 280;
	$vyska_ramu = 157.5;
}
else {
	$sirka_ramu = 560;
	$vyska_ramu = 315;
}


echo "<table>";

echo "<tr><td>Popisek:</td>";
echo "<td>";
echo $popisek;
echo "</td>";

echo "<tr><td>ID videa:</td>";
echo "<td>";
echo $id_videa;
echo "</td>";

echo "<tr><td>Velikost (šířka rámu):</td>";
echo "<td>";
echo $sirka_ramu;
echo "</td>";

echo "<tr><td>Velikost (výska rámu):</td>";
echo "<td>";
echo $vyska_ramu;
echo "</td>";

echo "<tr><td>Hodina:</td>";
echo "<td>";
echo $hodina;
echo "</td>";

echo "</table>";


$vysledek = mysqli_query($spojeni,  
"INSERT INTO `videa` (`id`, `popisek`, `id_videa`, `sirka`, `vyska`, `skola`) VALUES ('', '$popisek', '$id_videa', '$sirka_ramu', '$vyska_ramu', '$hodina')");
/* Konec přímé práce s databází. */

echo "<a href='index.php?s=2'>Z P Ě T</a>";
?>