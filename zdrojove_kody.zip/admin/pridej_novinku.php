<?php
$nadpis = "Správa lekcí";
require "pripojeni.php";
echo "<h1>$nadpis</h1>";

$nadpis = isset($_POST['nadpis']) ? $_POST['nadpis'] : "";
$text = isset($_POST['editor1']) ? $_POST['editor1'] : "";
$autor = htmlspecialchars($_SESSION['login']);

echo "<div class='ramecek_uvod'>";
echo "<h2>";
echo $nadpis;
echo "</h2>";
echo "<p>";
echo $text;
echo "</p>";
echo "<div class='podpisovka'>";
echo $autor;
echo " (";
echo "datum";
echo ")</div>";
echo "</div><br>";


$vysledek = mysqli_query($spojeni,  
"INSERT INTO `novinky` (`id`, `nadpis`, `text`, `autor`, `datum`) VALUES ('', '$nadpis', '$text', '$autor', CURRENT_TIMESTAMP);");
/* Konec přímé práce s databází. */

echo "<a href='index.php?s=4'>Z P Ě T</a>";
?>