<?php
$nadpis = "Založení galerie";
require "pripojeni.php";
echo "<h1>$nadpis</h1>";
function velikost($soubor) {
  $size = @filesize("./".$soubor);
  if($size < 1024) {$size = ($size); $k = " B";}
  if($size >= 1024) {$size = ($size / 1024); $k = " kB";}
  if($size >= 1024) {$size = ($size / 1024); $k = " MB";}
  return round($size, 1).$k; /* 1 = zaokrouhlování na jedno desetinné místo */
}
// ošetřední nedefinovaných proměnných
$nazev_galerie = isset($_GET["nazev_galerie"]) ? $_GET["nazev_galerie"] : "";


echo "<form action='index.php?s=zaloz_galerii' method='post'>";
echo "<table>
	<tr>
		<td>název galerie:</td>
		<td><input type='text' name='nazev_galerie'/></td>
	</tr>
	<!--<tr>
		<td>galerie bude zobrazena <br>v těchto školách:</td>
		<td>
			<input type='checkbox' name='check_list[]' value='skola1'><label>Škola1</label><br/>
			<input type='checkbox' name='check_list[]' value='skola2'><label>Škola2</label><br/>
			<input type='checkbox' name='check_list[]' value='skola3'><label>Škola3</label><br/>
			<input type='checkbox' name='check_list[]' value='skola4'><label>Škola4</label><br/>
			<input type='checkbox' name='check_list[]' value='skola5'><label>Škola5</label><br/>
		</td>
	</tr>-->
	<tr>
		<td><input type='submit' name='submit' value='Odeslat' /></td>
		<td></td>
	</tr>
</table>
</form>";

echo "<h2>Seznam galerií:</h2>";
echo "<table>";
echo "<b><tr><td>cesta k souboru</td><td>velikost</td><td>naposledy upraveno</td></tr></b>";

foreach (glob("../fotogalerie/*/") as $filename) {
	$filename_basename = basename($filename);
	echo "<tr>";
    echo "<td><a href='?s=12&akce=zobraz&galerie=$filename_basename'>$filename_basename</a></td>";
	echo "<td>" . velikost($filename) . "</td>";
	echo "<td>" . date ('d. m. Y H:i:s', filemtime($filename)) . "</td>";
	echo "<td>" . "<i>skoly</i>" . "<td>";
	echo "<td><a href='?s=12&akce=odstran&soubor=$filename_basename'>odstranit galerii</a><td>";
	echo "</tr>";
}
echo "</table>";

if (!isset($_GET['akce'])){$_GET['akce']='';}
if ($_GET['akce'] == "odstran")
{
	$soubor = $_GET['soubor'];
	rmdir($filename);
}

if (!isset($_GET['akce'])){$_GET['akce']='';}
if ($_GET['akce'] == "zobraz")
{
	$galerie = $_GET['galerie'];
	echo "<h2>Zobrazení galerie: " . $galerie . "</h2>";
	echo "<table>";
echo "<b><tr><td></td><td>cesta k souboru</td><td>velikost</td><td>naposledy upraveno</td></tr></b>";
	foreach (glob("../fotogalerie/$galerie/*") as $filename1) {
	$filename_basename1 = basename($filename1);
	echo "<tr>";
	echo "<td><img src='" . $filename1 . "' width='55px' height='55px' />";
    echo "<td><a href='$filename1'>$filename_basename1</a></td>";
	echo "<td>" . velikost($filename1) . "</td>";
	echo "<td>" . date ('d. m. Y H:i:s', filemtime($filename1)) . "</td>";
	echo "<td><a href='?s=12&akce=zobraz&galerie=$filename_basename&akce1=odstran&soubor=$filename_basename1'>odstranit</a><td>";
	echo "</tr>";
}
echo "</table>";

echo $filename1;

if (!isset($_GET['akce1'])){$_GET['akce1']='';}
if ($_GET['akce1'] == "odstran")
{
	$soubor = $_GET['soubor'];
	unlink($filename1);
}

	
}



?>