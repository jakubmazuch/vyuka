<?php
$nadpis = "Úprava hodin";
require "pripojeni.php";
echo "<h1>$nadpis</h1>";

$text = isset($_POST['editor1']) ? $_POST['editor1'] : "";

echo $text;


$vysledek = mysqli_query($spojeni,  
"UPDATE `uvodni_stranka` SET `text` = '$text';");
echo "<br/>Příkaz<br/>";
echo "<div class='okHlaska'>" . "UPDATE `uvodni_stranka` SET `text` = '$text';)" . "</div>";
/* Konec přímé práce s databází. */
?>