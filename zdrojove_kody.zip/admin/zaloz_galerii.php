<?php
$nadpis = "Založení galerie";
require "pripojeni.php";
echo "<h1>$nadpis</h1>";

$nazev_galerie = isset($_POST['nazev_galerie']) ? $_POST['nazev_galerie'] : "";
// ošetření nepovolených znaků + pozor na dablované názky složek! http://howto.imba.cz/index.php?alias=windows-zakazane-znaky
mkdir("../fotogalerie/$nazev_galerie", 0700);

echo "<div class='okHlaska'>V adresáři fotogalerie byla vytvořena složka s názvem <b>$nazev_galerie</b></div>";

// odkaz zpět
echo "<a href='";
echo "index.php";
echo "'>Z P Ě T</a>";
?>