<?php
$nadpis = "Úprava lekce";
require "pripojeni.php";
echo "<h1>$nadpis</h1>";

$id = isset($_POST['id_5']) ? $_POST['id_5'] : "";
$soubor = isset($_POST['soubor_5']) ? $_POST['soubor_5'] : "";
$nazev_lekce = isset($_POST['nazev_lekce_5']) ? $_POST['nazev_lekce_5'] : "";
$hodina = isset($_POST['hodina']) ? $_POST['hodina'] : "";

echo "<table>";

echo "<tr><td>ID:</td>";
echo "<td>";
echo $id;
echo "</td>";

echo "<tr><td>NÁZEV LEKCE:</td>";
echo "<td>";
echo $nazev_lekce;
echo "</td>";

echo "<tr><td>HODINA:</td>";
echo "<td>";
echo $hodina;
echo "</td>";

echo "<tr><td>SOUBOR (fileName):</td>";
echo "<td>";
echo $soubor;
echo "</td>";
echo "</table>";

$vysledek = mysqli_query($spojeni,  
"UPDATE `soubory` SET `nazev_lekce` = '$nazev_lekce', `soubor` = '$soubor', `hodina` = '$hodina' WHERE `soubory`.`id` = $id;");
echo "<br/>Příkaz<br/>";
echo "UPDATE `soubory` SET `nazev_lekce` = '$nazev_lekce', `soubor` = '$soubor', `hodina` = '$hodina' WHERE `soubory`.`id` = $id;";
/* Konec přímé práce s databází. */
?>