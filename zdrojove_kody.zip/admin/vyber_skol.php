<?php
/* ROLETKA */
require "pripojeni.php";

$vysledek = mysqli_query($spojeni,  
"SELECT * FROM `hodiny` ORDER BY `id` DESC");
/* Konec přímé práce s databází. */

echo "<tr><td>Skupina:</td><td><select name='hodina'>";

while ($zaznam = mysqli_fetch_array($vysledek) ): 

echo "<option value='";
echo $zaznam["nazev_robot"];
echo "'>";
echo $zaznam["nazev_zkr"];
echo "</option>";

endwhile;
echo "</select></td></tr>";
?>