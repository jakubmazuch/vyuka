<?php
$nadpis = "Správce videí";
require "pripojeni.php";
echo "<h1>$nadpis</h1>";

//ošetření nedefinovaných proměnných
$vysledek2 = isset($_GET["vysledek2"]) ? $_GET["vysledek2"] : "";
$id_2 = isset($_GET["id_2"]) ? $_GET["id_2"] : "";
$nazev_lekce = isset($_GET["nazev_lekce"]) ? $_GET["nazev_lekce"] : "";
$souborx = isset($_GET["souborx"]) ? $_GET["souborx"] : "";

//text
echo "Pro odstranění řádku je nutno kliknou dvakrát na odkaz 'Odstranit'";

//Výpis celé tabulky, řadit od nejmladšího dle datumu
$vysledek = mysqli_query($spojeni,  
"SELECT * FROM `videa` ORDER BY `id`");


//Odstranění řádku
if (!isset($_GET['akce'])){$_GET['akce']='';}
if ($_GET['akce'] == "odstran")
{
	$id = $_GET['id'];
$vysledek1 = mysqli_query($spojeni, 
"DELETE FROM `videa` WHERE id=$id");
}


/* Konec přímé práce s databází. */
echo "<table border='1' style='table-layout: fixed; border-collapse: collapse;'>";
echo "<tr>
	<td><b>id:</b></td>
	<td><b>popisek:</b></td>
	<td><b>id_videa:</b></td>
	<td><b>skola:</b></td>
	<td><b>X</b></td>
</tr>";

while ($zaznam = mysqli_fetch_array($vysledek) ): 

echo "<tr>";

echo "<td>";
echo $zaznam["id"];
echo "</td>";

echo "<td>";
echo $zaznam["popisek"];
echo "</td>";

echo "<td>";
echo $zaznam["id_videa"];
echo "</td>";

echo "<td>";
echo $zaznam["skola"];
echo "</td>";

echo "<td>";
echo "<a href=";
echo "?s=11&akce=odstran&id=";
echo $zaznam['id'];
echo ">";
echo "odstranit</a>";
echo "</td>";

echo "</tr>";
endwhile;

echo "</table>";
?>


<?php

// odkaz zpět
echo "<a href='";
echo "index.php";
echo "'>Z P Ě T</a>";
?>