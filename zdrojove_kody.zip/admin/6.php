<?php
$nadpis = "Přidej hodinu";
require "pripojeni.php";
echo "<h1>$nadpis</h1>";
?>
<!--//Fomulář pro přidání novinek-->

<form method="post">
<table>
<!-- <tr><td>předmět:</td><td><select name="predmet">
						<option value="IT Kroužek">IT Kroužek</option>
						<option value="Elektrohry">Elektrohry</option>
						<option value="Matematika">Matematika</option>
						<option value="Vědecký kroužek">Vědecký kroužek</option>
					</select></td></tr> -->
					
<tr><td>předmět:</td><td><input type="text" name="predmet"/></td></tr>
<tr><td>škola:</td><td><input type="text" name="skola"/></td></tr>
<tr><td>den v týdnu:</td><td><select name="den">
						<option value="po">Pondělí</option>
						<option value="ut">Úterý</option>
						<option value="st">Středa</option>
						<option value="ct">Čtvrtek</option>
						<option value="pa">Pátek</option>
						<option value="so">Sobota</option>
						<option value="ne">Neděle</option>
					</select></td></tr>
					
<tr><td>Začátek hodiny:</td><td><input type="time" name="cas1"/></td></tr>
<tr><td>Konec hodiny:</td><td><input type="time" name="cas2"/></td></tr>

<tr><td>název (zkr.):</td><td><input type="text" name="nazev_zkr"/></td></tr>
<tr><td>název (robot):</td><td><input type="text" name="nazev_robot"/></td></tr>
<tr><td>viditelnost:</td><td>
	<input type="radio" name="visible" value="0">0</input>
	<input type="radio" name="visible" value="1" checked="checked">1</input>
</td></tr>
<tr><td>zobrazit tyto sekce:</td><td>
	<input type="checkbox" name="check_list[]" value="Text"><label>Text</label><br/>
	<input type="checkbox" name="check_list[]" value="Výukové soubory"><label>Výukové soubory</label><br/>
	<input type="checkbox" name="check_list[]" value="Odkazy"><label>Odkazy</label><br/>
	<input type="checkbox" name="check_list[]" value="Fotogalerie"><label>Fotogalerie</label><br/>
	<input type="checkbox" name="check_list[]" value="Videogalerie"><label>Videogalerie</label><br/>
</td></tr>

<tr><td><input type="submit" name="submit" value="Odeslat" /></td></tr>
</table>
</form>

<?php

$predmet = isset($_POST['predmet']) ? $_POST['predmet'] : "";
$skola = isset($_POST['skola']) ? $_POST['skola'] : "";
$den = isset($_POST['den']) ? $_POST['den'] : "";
$cas1 = isset($_POST['cas1']) ? $_POST['cas1'] : "";
$cas2 = isset($_POST['cas2']) ? $_POST['cas2'] : "";
$nazev_zkr = isset($_POST['nazev_zkr']) ? $_POST['nazev_zkr'] : "";
$nazev_robot = isset($_POST['nazev_robot']) ? $_POST['nazev_robot'] : "";
$visible = isset($_POST['visible']) ? $_POST['visible'] : "";

$cas_final = "($den) $cas1 - $cas2";


echo "<table>";

echo "<tr><td>PŘEDMĚT::</td>";
echo "<td>";
echo $predmet;
echo "</td>";

echo "<tr><td>ŠKOLA:</td>";
echo "<td>";
echo $skola;
echo "</td>";

echo "<tr><td>DEN a ČAS:</td>";
echo "<td>";
echo $cas_final;
echo "</td>";

echo "<tr><td>NÁZEV (zkr.):</td>";
echo "<td>";
echo $nazev_zkr;
echo "</td>";

echo "<tr><td>NÁZEV (robot):</td>";
echo "<td>";
echo $nazev_robot;
echo "</td>";

echo "<tr><td>ZOBRAZIT TYTO SEKCE:</td>";
echo "<td>";

$sekce = implode(", ", $_POST['check_list']);
echo $sekce;

echo "</td>";

echo "<tr><td>VISIBLE:</td>";
echo "<td>";
echo $visible;
echo "</td>";

echo "</table>";



if ($skola == NULL or $cas1 > $cas2 or $nazev_zkr == NULL or $nazev_robot == NULL) {
	$hlaska = "<div class='chybovaHlaska'>Chyba</div>";
}
else {
	$prikaz = "INSERT INTO `hodiny` (`id`, `predmet`, `skola`, `cas`, `nazev_zkr`, `nazev_robot`, `oddeleni`, `visible`)". "<br>". "VALUES ('', '$predmet', '$skola', '$cas_final', '$nazev_zkr', '$nazev_robot', '$sekce', '$visible')";
	$hlaska = "<div class='okHlaska'>Byl proveden příkaz $prikaz, který ovlivnil 1 řádek.</div>";

	$vysledek = mysqli_query($spojeni,  
	"INSERT INTO `hodiny` (`id`, `predmet`, `skola`, `cas`, `nazev_zkr`, `nazev_robot`, `oddeleni`, `visible`) VALUES ('', '$predmet', '$skola', '$cas_final', '$nazev_zkr', '$nazev_robot', '$sekce', '$visible')");
	/* Konec přímé práce s databází. */
}
echo $hlaska;

echo "<a href='index.php?s=6'>Z P Ě T</a>";

?>