<?php
$nadpis = "Přidej odkaz";
require "pripojeni.php";
echo "<h1>$nadpis</h1>";

//Fomulář pro přidání odkazu do školy
echo " <form action='index.php?s=pridej_odkaz' method='post'>";
echo "<table>
		<tr><td>Popisek adresy:</td><td><input type='text' name='popisek'/></td></tr>
		<tr><td>URL adresy:</td><td><input type='url' name='url' value='http://'/></td></tr>
		<!--
		<tr><td>Cíl odkazu (target):</td><td><select name='cil'>
						<option value='_blank'>_blank (nové okno nebo nový tab)</option>
						<option value='_top'>_top (nejvyšší okno hierarchie rámů)</option>
						<option value='_parent'>_parent (nadřazený rám)</option>
						<option value='_self'>_self (tentýž rám)</option>
					</select></td></tr>
		-->	";
			$vysledek1 = mysqli_query($spojeni,  
			"SELECT * FROM `hodiny` WHERE `visible`");
			/* Konec přímé práce s databází. */

			echo "<tr><td>Hodina:</td><td><select name='hodina'>";

			while ($zaznam = mysqli_fetch_array($vysledek1) ): 

			echo "<option value='";
			echo $zaznam["nazev_robot"];
			echo "'>";
			echo $zaznam["nazev_zkr"];
			echo "</option>";

			endwhile;
			echo "</select></td></tr>
		<tr><td><input type='submit' value='Odeslat' /></td></tr>";
echo "</table>";
echo "</form>";


?>