<?php
$nadpis = "Úprava hodin";
require "pripojeni.php";
echo "<h1>$nadpis</h1>";

$id_upr = isset($_POST['id_5']) ? $_POST['id_5'] : "";
$predmet_upr = isset($_POST['Predmet_5']) ? $_POST['Predmet_5'] : "";
$skola_upr = isset($_POST['skola_5']) ? $_POST['skola_5'] : "";
$cas_upr = isset($_POST['cas_5']) ? $_POST['cas_5'] : "";
$nazev_zkr_upr = isset($_POST['nazev_zkr_5']) ? $_POST['nazev_zkr_5'] : "";
$nazev_robot_upr = isset($_POST['nazev_robot_5']) ? $_POST['nazev_robot_5'] : "";
$visible_upr = isset($_POST['visible_5']) ? $_POST['visible_5'] : "";

echo "<table>";

echo "<tr><td>ID:</td>";
echo "<td>";
echo $id_upr;
echo "</td>";

echo "<tr><td>PŘEDMĚT:</td>";
echo "<td>";
echo $predmet_upr;
echo "</td>";

echo "<tr><td>ŠKOLA:</td>";
echo "<td>";
echo $skola_upr;
echo "</td>";

echo "<tr><td>ČAS:</td>";
echo "<td>";
echo $cas_upr;
echo "</td>";

echo "<tr><td>ŠKOLA (zkr.):</td>";
echo "<td>";
echo $nazev_zkr_upr;
echo "</td>";

echo "<tr><td>ŠKOLA (robot):</td>";
echo "<td>";
echo $nazev_robot_upr;
echo "</td>";

echo "<tr><td>ZOBRAZIT TYTO SEKCE:</td>";
echo "<td>";

if(isset($_POST['submit'])){//to run PHP script on submit
if(!empty($_POST['check_list'])){
// Loop to store and display values of individual checked checkbox.
foreach($_POST['check_list'] as $selected){
	echo $selected;
}}}
echo "</td>";

echo "<tr><td>VISIBLE:</td>";
echo "<td>";
echo $visible_upr;
echo "</td>";

echo "</table>";

$sekce = implode(", ", $_POST['check_list']);

$vysledek = mysqli_query($spojeni,  
"UPDATE `hodiny` SET `id` = '$id_upr', `predmet` = '$predmet_upr', `skola` = '$skola_upr', `cas` = '$cas_upr', `nazev_zkr` = '$nazev_zkr_upr', `nazev_robot` = '$nazev_robot_upr', `oddeleni` = '$sekce', `visible` = '$visible_upr' WHERE `hodiny`.`id` = $id_upr;");
echo "<br/>Příkaz<br/>";
echo "UPDATE `hodiny` SET `id` = '$id_upr', `predmet` = '$predmet_upr', `skola` = '$skola_upr', `cas` = '$cas_upr', `nazev_zkr` = '$nazev_zkr_upr', `nazev_robot` = '$nazev_robot_upr', `oddeleni` = '$sekce', `visible` = '$visible_upr' WHERE `hodiny`.`id` = $id_upr;)";
/* Konec přímé práce s databází. */
?>