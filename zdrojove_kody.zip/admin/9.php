<?php
$nadpis = "Editace úvodní stránky";
require "pripojeni.php";
echo "<h1>$nadpis</h1>";

//
$vysledek = mysqli_query($spojeni,  
	"SELECT * FROM `uvodni_stranka`");
/* Konec přímé práce s databází. */

if ($vysledek->num_rows > 0) {		
while ($zaznam = mysqli_fetch_array($vysledek) ): 

$text = $zaznam["text"];

endwhile;
}

//Formulář pro editaci úvodní stránky
echo "
<form action='index.php?s=pridej_na_uvod' method='post'>
<textarea name='editor1' id='editor1' rows='10' cols='80'>$text</textarea>
<script>
CKEDITOR.replace( 'editor1' );
</script></td></tr>
<input type='submit' value='Odeslat' />
</form>
";


?>