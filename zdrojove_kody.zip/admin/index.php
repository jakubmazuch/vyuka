<?php
session_start();


if((!empty( $_POST['login'])) && (!empty($_POST['password'])))
{
	$login = isset($_POST['login']) ? $_POST['login'] : "";
   if((($_POST['login'] == 'user')) && (($_POST['password'] == '*****')))
     {
		 //souhlasí, nastavíme session, může jich být více a můžeš v nich přenášet třeba jméno přihlášeného...
         $_SESSION['prihlasen'] = 1;
		 $_SESSION['login'] = $login;
         //a znovunačteme stránku (předpokládám že je to index v kořeni webu
		 
      }
	  else
      {
         //nesouhlasí
         include ("hlavicka1.php");
		 echo "<div class='chybovaHlaska'>Špatné přihlašovací jméno nebo heslo.</div>";
		 include ("../formular_pro_prihlaseni.php");
	}
}
if(isset($_GET['odhlasit']))
{
    session_destroy();
	echo "Jste odhlášen! <br/>";
	echo "<a href='../index.php'>DOMŮ</a>";
	die;
    
}
if((!empty($_SESSION['prihlasen']))and($_SESSION['prihlasen']===1))
{
	include ("hlavicka1_A.php");
	echo "<div style='text-align: right'>";
	echo "<p>Jste přihlášen jako uživatel " .htmlspecialchars($_SESSION['login'], ENT_QUOTES). " | <a href='index.php?odhlasit'>Odhlásit se.</a></p>";
	echo "</div>";

	$stranka = $_GET['s'];
		$soubor = $stranka.".php"; // cesta do adresáře
		if (!file_exists($soubor)) 
		{
			$soubor = "uvod.php";
		}
		include ($soubor);
	include ("../paticka1.php");
	}	   
else {



	include ("../paticka1.php");

}



?>