<?php
$nadpis = "Smazání a úprava řádku";
require "pripojeni.php";
echo "<h1>$nadpis</h1>";

//ošetření nedefinovaného fileName
$vysledek2 = isset($_GET["vysledek2"]) ? $_GET["vysledek2"] : "";
$id_2 = isset($_GET["id_2"]) ? $_GET["id_2"] : "";
$nazev_lekce = isset($_GET["nazev_lekce"]) ? $_GET["nazev_lekce"] : "";
$souborx = isset($_GET["souborx"]) ? $_GET["souborx"] : "";

//Filtr pro výběr škol
$vysledek4 = mysqli_query($spojeni,  
	"SELECT * FROM `hodiny` WHERE `visible`");
	echo "<p/>vše | ";
	while ($zaznam1 = mysqli_fetch_array($vysledek4) ): 
	echo "<a href='?s=7&skola=" . $zaznam1["nazev_robot"] . "'>" . $zaznam1["nazev_zkr"] . "</a> | ";
	endwhile;
	echo "</p>";
	
$skola = isset($_GET["skola"]) ? $_GET["skola"] : "";
if (!isset($_GET['skola'])){$_GET['skola']='';}
if ($_GET['skola'] == $skola)
{
	echo "Vybrána škola " . $skola . ".";
}	
$vysledek = mysqli_query($spojeni,  
"SELECT * FROM `soubory` WHERE nazev_robot=$skola ORDER BY `soubory`.`datum` DESC");
	
	
//text
echo "<p>Pro odstranění řádku je nutno kliknou dvakrát na odkaz 'Odstranit'</p>";

//Úprava řádku
if (!isset($_GET['akce'])){$_GET['akce']='';}
if ($_GET['akce'] == "uprav")
{
	$id = $_GET['id'];
$vysledek2 = mysqli_query($spojeni, 
"SELECT * FROM `soubory` WHERE id=$id");
}
if ($vysledek2->num_rows > 0) {	
	

	while ($zaznam2 = mysqli_fetch_array($vysledek2) ): 
	$id_2 = $zaznam2["id"];
	$nazev_lekce = $zaznam2["nazev_lekce"];
	$souborx = $zaznam2["soubor"];
	$datum = $zaznam2["datum"];
	endwhile;
	
	//formulář pro úpravu záznamu
	echo "<table border='1' style='table-layout: fixed; border-collapse: collapse;'>";
	echo "<tr>
		<td><b>id:</b></td>
		<td><b>název lekce:</b></td>
		<td><b>soubor:</b></td>
		<td><b>datum:</b></td>
		<td><b>hodina:</b></td>
		<td> </td>
	</tr>";
	
	echo "<form action='index.php?s=uprava' method='post'>";
	echo "<tr>";
	echo "<td>";
	echo "<input type='text' value='$id_2' name='id_5' size='3' readonly/>";
	echo "</td>";

	echo "<td>";
	echo "<input type='text' value='$nazev_lekce' name='nazev_lekce_5' size='15'/>";
	echo "</td>";

	echo "<td>";
	echo "<input type='text' value='$souborx' name='soubor_5' size='15'/>";
	echo "</td>";

	echo "<td>";
	echo $datum;
	echo "</td>";

	echo "<td>";
	$vysledek1 = mysqli_query($spojeni,  
	"SELECT * FROM `hodiny` WHERE `visible`");

	echo "<select name='hodina'>";

	while ($zaznam = mysqli_fetch_array($vysledek1) ): 
	echo "<option value='";
	echo $zaznam["nazev_robot"];
	echo "'>";
	echo $zaznam["nazev_zkr"];
	echo "</option>";

	endwhile;
	echo "</select>";
	echo "</td>";
	
	echo "<td>";
	echo "<input type='submit' value='Odeslat' />";
	echo "</td>";

	echo "</tr>";
	echo "</form>";
	echo "</table><br/><br/><br/>";
}
else {
	echo "";
}

//Výpis celé tabulky, řadit od nejmladšího dle datumu
$vysledek = mysqli_query($spojeni,  
"SELECT * FROM `soubory` ORDER BY `soubory`.`datum` DESC");


//Odstranění řádku
if (!isset($_GET['akce'])){$_GET['akce']='';}
if ($_GET['akce'] == "odstran")
{
	$id = $_GET['id'];
$vysledek1 = mysqli_query($spojeni, 
"DELETE FROM `soubory` WHERE id=$id");
}


/* Konec přímé práce s databází. */

echo "<table border='1' style='table-layout: fixed; border-collapse: collapse;'>";
echo "<tr>
	<td><b>id:</b></td>
	<td><b>název lekce:</b></td>
	<td><b>soubor:</b></td>
	<td><b>datum:</b></td>
	<td><b>hodina:</b></td>
	<td><b>X</b></td>
</tr>";

while ($zaznam = mysqli_fetch_array($vysledek) ): 

echo "<tr>";

echo "<td>";
echo $zaznam["id"];
echo "</td>";

echo "<td>";
echo $zaznam["nazev_lekce"];
echo "</td>";

echo "<td>";
echo $zaznam["soubor"];
echo "</td>";

echo "<td>";
echo $zaznam["datum"];
echo "</td>";




	$i = 0;
	$vysledek1 = mysqli_query($spojeni,  
	"SELECT * FROM `hodiny` WHERE `visible`");
	while ($zaznam4 = mysqli_fetch_array($vysledek1) ): 
		$a[$i] = $zaznam4["nazev_robot"];
		$i++;
	endwhile;
	$b = in_array($zaznam["hodina"], $a);
if ($b <> 1) {
	echo "<td bgcolor='#FCF'>";
	echo "<b style='color: red;'>";
	echo $zaznam["hodina"] . " (!)";
	echo "</b></td>";
}
else {
	echo "<td>";
	echo $zaznam["hodina"];
	echo "</td>";
}


echo "<td>";
echo "<a href=";
echo "?s=7&akce=odstran&id=";
echo $zaznam['id'];
echo ">";
echo "odstranit</a>";
echo "<br>";
echo "<a href=";
echo "?s=7&akce=uprav&id=";
echo $zaznam['id'];
echo ">";
echo "upravit</a>";
echo "</td>";

echo "</tr>";


endwhile;
echo "</table>";

// odkaz zpět
echo "<a href='";
echo "index.php?s=7.php";
echo "'>Z P Ě T</a>";
?>