<?php
/* MENU */
require "../pripojeni.php";
require "../menu.php";
?>
<div id='menu'>
<a href="index.php?s=9"><div class="menuLink">Editace úvodní strany</div></a>
<a href="index.php?s=4"><div class="menuLink">novinky a informace</div></a>
<a href="index.php?s=6"><div class="menuLink">hodiny - vložení</div></a>
<a href="index.php?s=5"><div class="menuLink">hodiny - správa</div></a>
<a href="index.php?s=3"><div class="menuLink">výukové materiály - vložení</div></a>
<a href="index.php?s=7"><div class="menuLink">výukové materiály - správa</div></a>
<a href="index.php?s=2"><div class="menuLink">odkazy - vložení</div></a>
<a href="index.php?s=8"><div class="menuLink">odkazy - správa</div></a>
<a href="index.php?s=10"><div class="menuLink">videa - vložení</div></a>
<a href="index.php?s=11"><div class="menuLink">videa - správa</div></a>
<a href="index.php?s=12"><div class="menuLink">fotogalerie - založení galerie (×)</div></a>
<a href="index.php?s=13"><div class="menuLink">fotogalerie - upload fotek (×)</div></a>
</div>
