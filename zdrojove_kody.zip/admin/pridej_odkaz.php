<?php
$nadpis = "Přidej hodinu";
require "pripojeni.php";
echo "<h1>$nadpis</h1>";

$popisek = isset($_POST['popisek']) ? $_POST['popisek'] : "";
$url = isset($_POST['url']) ? $_POST['url'] : "";
$cil = isset($_POST['cil']) ? $_POST['cil'] : "";
$hodina = isset($_POST['hodina']) ? $_POST['hodina'] : "";

echo "<table>";

echo "<tr><td>POPISEK:</td>";
echo "<td>";
echo $popisek;
echo "</td>";

echo "<tr><td>URL adresa:</td>";
echo "<td>";
echo $url;
echo "</td>";

echo "<tr><td>CÍL:</td>";
echo "<td>";
echo $cil;
echo "</td>";

echo "<tr><td>HODINA:</td>";
echo "<td>";
echo $hodina;
echo "</td>";

echo "</table>";


$vysledek = mysqli_query($spojeni,  
"INSERT INTO `odkazy` (`id`, `popisek`, `url`, `skola`) VALUES ('', '$popisek', '$url', '$hodina')");
/* Konec přímé práce s databází. */

echo "<a href='index.php?s=2'>Z P Ě T</a>";
?>