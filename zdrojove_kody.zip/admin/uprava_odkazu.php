<?php
$nadpis = "Úprava odkazu";
require "pripojeni.php";
echo "<h1>$nadpis</h1>";

$id_upr = isset($_POST['id_upr']) ? $_POST['id_upr'] : "";
$popisek_upr = isset($_POST['popisek_upr']) ? $_POST['popisek_upr'] : "";
$skola_upr = isset($_POST['skola_upr']) ? $_POST['skola_upr'] : "";
$url_upr = isset($_POST['url_upr']) ? $_POST['url_upr'] : "";

echo "<table>";

echo "<tr><td>ID:</td>";
echo "<td>";
echo $id_upr;
echo "</td>";

echo "<tr><td>POPISEK:</td>";
echo "<td>";
echo $popisek_upr;
echo "</td>";

echo "<tr><td>URL:</td>";
echo "<td>";
echo $url_upr;
echo "</td>";

echo "<tr><td>ŠKOLA:</td>";
echo "<td>";
echo $skola_upr;
echo "</td>";

echo "</table>";


$vysledek = mysqli_query($spojeni,  
"UPDATE `odkazy` SET `id` = '$id_upr', `popisek` = '$popisek_upr', `url` = '$url_upr', `skola` = '$skola_upr' WHERE `odkazy`.`id` = $id_upr;");
echo "<br/>Příkaz<br/>";
echo "UPDATE `odkazy` SET `id` = '$id_upr', `popisek` = '$popisek_upr', `url` = '$url_upr', `skola` = '$skola_upr' WHERE `odkazy`.`id` = $id_upr;)";
/* Konec přímé práce s databází. */
?>