<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-92617882-1', 'auto');
  ga('send', 'pageview');

</script>
<?php
$nadpis = "Administrace";
echo "<h1>$nadpis</h1>";
function velikost($soubor) {
  $size = @filesize("./".$soubor);
  if($size < 1024) {$size = ($size); $k = " B";}
  if($size >= 1024) {$size = ($size / 1024); $k = " kB";}
  if($size >= 1024) {$size = ($size / 1024); $k = " MB";}
  return round($size, 1).$k; /* 1 = zaokrouhlování na jedno desetinné místo */
}
// ošetření nedefinovaných promenných
$file = isset($_GET["file"]) ? $_GET["file"] : "";

echo "<style>
	img {cursor: pointer; cursor: hand; text-decoration: underline}
	.skryvany {display: none}
	</style>";
echo "Vítej, milý uživateli! :-)";


?>
<h2>Odkazy:</h2>
<menu>
	<ul>
		<li><a href="http://www.gjszlin.cz/ivt/esf/php/php-prace-s-polem.php">Práce s polem</a></li>
		<li><a href="https://diskuse.jakpsatweb.cz/?action=vthread&forum=9&topic=118940">Data z db do pole</a></li>
	</ul>
</menu>
	
<h2>Seznam všech souborů:</h2>	
<?php
echo "<table>";
echo "<strong><tr><td>cesta k souboru</td><td>velikost</td><td>naposledy upraveno</td></tr></strong>";

foreach (glob("../soubory/soubory/*") as $filename) {
	$filename_base = basename($filename); 
	echo "<tr>";
    echo "<td><a target='_parent' href='$filename'>$filename_base</a></td>";
	echo "<td>" . velikost($filename) . "</td>";
	echo "<td>" . date ('d. m. Y H:i:s', filemtime($filename)) . "</td>";
	echo "<td><a href='index.php?action=delete&file=$filename_base'>smazat soubor</a>";
	echo "</tr>";
}
	unlink('../soubory/soubory/'.$_GET['file']);
	echo "</table>";
?>

