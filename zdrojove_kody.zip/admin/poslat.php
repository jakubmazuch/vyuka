<?php
$nadpis = "Správa lekcí";
require "pripojeni.php";
echo "<h1>$nadpis</h1>";

$soubor = isset($_POST['soubor']) ? $_POST['soubor'] : "";
$nazev_lekce = isset($_POST['nazev_lekce']) ? $_POST['nazev_lekce'] : "";
$hodina = isset($_POST['hodina']) ? $_POST['hodina'] : "";

echo "<table>";
echo "<tr><td>NÁZEV LEKCE:</td>";
echo "<td>";
echo $nazev_lekce;
echo "</td>";

echo "<tr><td>HODINA:</td>";
echo "<td>";
echo $hodina;
echo "</td>";

echo "<tr><td>SOUBOR (fileName):</td>";
echo "<td>";
echo $soubor;
echo "</td>";
echo "</table>";


$vysledek = mysqli_query($spojeni,  
"INSERT INTO `soubory` (`id`, `nazev_lekce`, `soubor`, `datum`, `hodina`) VALUES ('', '$nazev_lekce', '$soubor', CURRENT_TIMESTAMP, '$hodina');");
/* Konec přímé práce s databází. */
?>