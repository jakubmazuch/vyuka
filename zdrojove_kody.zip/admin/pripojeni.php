<?php
$server = "localhost";
$jmeno = "root";
$heslo = "";
$spojeni = mysqli_connect($server, $jmeno, $heslo, "d82888_krouzk1");
mysqli_query($spojeni, "SET NAMES 'utf8'"); 
?>