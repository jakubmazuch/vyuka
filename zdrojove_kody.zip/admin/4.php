<?php
$nadpis = "Správa novinek";
require "pripojeni.php";
echo "<h1>$nadpis</h1>";

//Fomulář pro přidání novinek
echo "
<form action='index.php?s=pridej_novinku' method='post'>
<table>
<tr><td>nadpis:</td><td><input type='text' name='nadpis'/></td></tr>
<tr><td>text:</td><td><textarea name='editor1' id='editor1' rows='10' cols='80' placeholder='Sem napište obsah zprávy.'>     
            </textarea>
            <script>
                CKEDITOR.replace( 'editor1' );
            </script></td></tr>
<tr><td><input type='submit' value='Odeslat' /></td></tr>
</table>
</form>
";

echo "<br/>";

//Odstranění řádku
if (!isset($_GET['akce'])){$_GET['akce']='';}
if ($_GET['akce'] == "del")
{
	$id = $_GET['id'];
$vysledek1 = mysqli_query($spojeni, 
"DELETE FROM `novinky` WHERE id=$id");
}

//Výpis novinek
$vysledek = mysqli_query($spojeni,  
	"SELECT *, 
	date_format (datum, '%e. %c. %Y, %H:%i:%s') AS datum_cs 
	FROM `novinky`
	ORDER BY `datum` DESC");
/* Konec přímé práce s databází. */

if ($vysledek->num_rows > 0) {		
while ($zaznam = mysqli_fetch_array($vysledek) ): 

echo "<div class='ramecek_uvod'>";
echo "<h2>";
echo "<a href=";
echo "?s=4&akce=del&id=";
echo $zaznam['id'];
echo ">";
echo "X  </a>";
echo $zaznam["nadpis"];
echo "</h2>";
echo "<p>";
echo $zaznam["text"];
echo "</p>";
echo "<div class='podpisovka'>";
echo $zaznam["autor"];
echo " (";
echo $zaznam["datum_cs"];
echo ")</div>";
echo "</div><br>";

endwhile;
}
	else {
		echo "<i>(žádné novinky k zobrazení)</i>";
	}

?>