<?php
$nadpis = "Správce hodin";
require "pripojeni.php";
echo "<h1>$nadpis</h1>";

//ošetření nedefinovaného fileName
$vysledek2 = isset($_GET["vysledek2"]) ? $_GET["vysledek2"] : "";
$id_2 = isset($_GET["id_2"]) ? $_GET["id_2"] : "";
$nazev_lekce = isset($_GET["nazev_lekce"]) ? $_GET["nazev_lekce"] : "";
$souborx = isset($_GET["souborx"]) ? $_GET["souborx"] : "";

//text
echo "Pro odstranění řádku je nutno kliknou dvakrát na odkaz 'Odstranit'";

//Úprava řádku
if (!isset($_GET['akce'])){$_GET['akce']='';}
if ($_GET['akce'] == "uprav")
{
	$id = $_GET['id'];
$vysledek2 = mysqli_query($spojeni, 
"SELECT * FROM `hodiny` WHERE id=$id");
}
if ($vysledek2->num_rows > 0) {	
	

	while ($zaznam2 = mysqli_fetch_array($vysledek2) ): 
	$id_2 = $zaznam2["id"];
	$predmet_upr = $zaznam2["predmet"];
	$skola_upr = $zaznam2["skola"];
	$cas_upr = $zaznam2["cas"];
	$nazev_zkr_upr = $zaznam2["nazev_zkr"];
	$nazev_robot_upr = $zaznam2["nazev_robot"];
	$visible_upr = $zaznam2["visible"];
	endwhile;
	
	//formulář pro úpravu záznamu
	echo "<table frame='hsides' rules='groups' border='1' style='table-layout: fixed; border-collapse: collapse;'>";
	echo "<tr>
			<td><b>id:</b></td>
			<td><b>předmět:</b></td>
			<td><b>škola:</b></td>
			<td><b>čas:</b></td>
			<td><b>název (zkr.):</b></td>
			<td><b>název (robot):</b></td>
			<td><b>sekce::</b></td>
			<td><b>vis.:</b></td>
		</tr>";
	
	echo "<form action='index.php?s=uprava_hodin' method='post'>";
	echo "<tbody><tr>";
	
	echo "<td>";
	echo "<input type='text' value='$id_2' name='id_5' size='1' readonly/>";
	echo "</td>";

	echo "<td>";
	echo "<input type='text' value='$predmet_upr' name='Predmet_5' size='7'/>";
	echo "</td>";

	echo "<td>";
	echo "<input type='text' value='$skola_upr' name='skola_5' size='20'/>";
	echo "</td>";

	echo "<td>";
	echo "<input type='text' value='$cas_upr' name='cas_5' size='12'/>";
	echo "</td><br/><br/>";
	
	echo "<td>";
	echo "<input type='text' value='$nazev_zkr_upr' name='nazev_zkr_5' size='10'/>";
	echo "</td>";
	
	echo "<td>";
	echo "<input type='text' value='$nazev_robot_upr' name='nazev_robot_5' size='10'/>";
	echo "</td>";
	
	echo "<td>";?>
	<input type="checkbox" name="check_list[]" value="Text"><label>Text</label><br/>
	<input type="checkbox" name="check_list[]" value="Výukové soubory"><label>Výukové soubory</label><br/>
	<input type="checkbox" name="check_list[]" value="Odkazy"><label>Odkazy</label><br/>
	<input type="checkbox" name="check_list[]" value="Fotogalerie"><label>Fotogalerie</label><br/>
	<input type="checkbox" name="check_list[]" value="Videogalerie"><label>Videogalerie</label><br/>
	<?php
	echo "</td>";
	
	echo "<td>";
	echo "<input type='text' value='$visible_upr' name='visible_5' size='1'/>";
	echo "</td>";

	echo "<td>";
	echo "<input type='submit' name='submit' value='Odeslat' />";
	echo "</td>";

	echo "</tr>";
	echo "</tbody></form>";
	echo "</table><br/><br/><br/>";
}
else {
	echo "";
}

//Výpis celé tabulky, řadit od nejmladšího dle datumu
$vysledek = mysqli_query($spojeni,  
"SELECT * FROM `hodiny` WHERE `id`!=1 ORDER BY `id`");


//Odstranění řádku
if (!isset($_GET['akce'])){$_GET['akce']='';}
if ($_GET['akce'] == "odstran")
{
	$id = $_GET['id'];
$vysledek1 = mysqli_query($spojeni, 
"DELETE FROM `hodiny` WHERE id=$id");
}


/* Konec přímé práce s databází. */

echo "<table border='1' style='table-layout: fixed; border-collapse: collapse;'>";
echo "<tr>
	<td><b>url:</b></td>
	<td><b>předmět:</b></td>
	<td><b>škola:</b></td>
	<td><b>čas:</b></td>
	<td><b>název (zkr.):</b></td>
	<td><b>název (robot):</b></td>
	<td><b>sekce:</b></td>
	<td><b>vis.:</b></td>
	<td><b>X</b></td>
</tr>";

while ($zaznam = mysqli_fetch_array($vysledek) ): 

echo "<tr>";

echo "<td>";
echo $zaznam["id"];
echo "</td>";

echo "<td>";
echo $zaznam["predmet"];
echo "</td>";

echo "<td>";
echo $zaznam["skola"];
echo "</td>";

echo "<td>";
echo $zaznam["cas"];
echo "</td>";

echo "<td>";
echo $zaznam["nazev_zkr"];
echo "</td>";

echo "<td>";
echo $zaznam["nazev_robot"];
echo "</td>";

echo "<td>";
echo $zaznam["oddeleni"];
echo "</td>";

echo "<td>";
echo $zaznam["visible"];
echo "</td>";

echo "<td>";
echo "<a href=";
echo "?s=5&akce=odstran&id=";
echo $zaznam['id'];
echo ">";
echo "odstranit</a>";
echo "<br>";
echo "<a href=";
echo "?s=5&akce=uprav&id=";
echo $zaznam['id'];
echo ">";
echo "upravit</a>";
echo "</td>";

echo "</tr>";


endwhile;
echo "</table>";

// odkaz zpět
echo "<a href='";
echo "index.php?s=5.php";
echo "'>Z P Ě T</a>";
?>
