<?php

$nadpis = "Vložení lekce a souboru";
echo "<h1>$nadpis</h1>";

//ošetření nedefinovaného fileName
$fileName = isset($_GET["fileName"]) ? $_GET["fileName"] : "";
 
// konfigurace
$uploadDir = '../soubory/soubory'; // adresar, kam se maji nahrat obrazky (bez lomitka na konci)
$allowedExt = array('jpg', 'jpeg', 'png', 'html', 'htm', 'gif', 'avi', 'bmp', 'docx', 'mp3', 'pdf', 'txt', 'wav', 'xlsx', 'zip', 'sb2',); // pole s povolenymi priponami
 
// zpracovani uploadu
if(isset($_FILES['obrazky']) && is_array($_FILES['obrazky']['name'])) {
 
    $counter = 0;
    $allowedExt = array_flip($allowedExt);
    foreach($_FILES['obrazky']['name'] as $klic => $nazev) {
 
        $fileName = basename($nazev);
        $tmpName = $_FILES['obrazky']['tmp_name'][$klic];
 
        // kontrola souboru
        if(
            !is_uploaded_file($tmpName)
            || !isset($allowedExt[strtolower(pathinfo($fileName, PATHINFO_EXTENSION))])
        ) {
            // neplatny soubor nebo pripona
            continue;
        }
 
        // presun souboru
        if(move_uploaded_file($tmpName, "{$uploadDir}".DIRECTORY_SEPARATOR."{$fileName}")) {
            ++$counter;
        }
 
    }
 
    echo "<p>Bylo nahráno {$counter} z ".sizeof($_FILES['obrazky']['name'])." souborů.</p>";
 
};

echo $fileName;
 
echo "
<h2>a) Upload souborů:</h2>
<form method='post' enctype='multipart/form-data'>
	<input type='file' name='obrazky[]' multiple='multiple' />
    <input type='submit' value='Nahrát' />
</form>";

echo "<hr/>";
echo "<h2>b) Zadání lekce</h2>";
echo "
<form action='index.php?s=poslat' method='post'>
<table>
	<tr><td>Název souboru:</td><td><input type='text'  value='$fileName' name='soubor' readonly/></td><td>Nelze měnit!</td></tr>
	<tr><td>Popis lekce:</td><td><input type='text' name='nazev_lekce'/></td></tr>";
	
			$vysledek1 = mysqli_query($spojeni,  
			"SELECT * FROM `hodiny` WHERE `visible`");
			/* Konec přímé práce s databází. */

			echo "<tr><td>Skupina:</td><td><select name='hodina'>";

			while ($zaznam = mysqli_fetch_array($vysledek1) ): 

			echo "<option value='";
			echo $zaznam["nazev_robot"];
			echo "'>";
			echo $zaznam["nazev_zkr"];
			echo "</option>";

			endwhile;
			echo "</select></td></tr>";

echo "<tr><input type='submit' value='Odeslat' /></tr>
</table>
</form>";

	?>