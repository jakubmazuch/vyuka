<?php
$soucasny_rok = Date("Y", Time());

echo "
</div>
<div style='clear:both;'></div>
</div>
<div id='paticka'>
   Copyright &copy 2017 - $soucasny_rok | Vytvořil: Jakub Mazuch (<a href='http://www.mazuch.net/'>www.mazuch.net</a>) | Všechna práva vyhrazena. | [<a href='login.php'>A</a>]
</div>
</div>
</body>
</html>";
?>